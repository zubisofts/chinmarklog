<template>
    <div class="bg-gray-300" id="banner">

    </div>
</template>


<style scoped>
    #banner{
        background: linear-gradient(to right , rgba(0, 0, 0, 0.801),rgba(0, 0, 0, 0.671),rgba(0, 0, 0, 0.548),transparent,transparent,transparent,transparent),url('/images/banner.jpg');
        content: '';
        background-size: cover;
        background-position: center top;
        background-attachment: fixed;
        min-height: 350px;
    }
</style>