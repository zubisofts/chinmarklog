<template>
    <div>
        <strong>
            <font-awesome-icon :icon="['far','bell']" style="font-size:1.3rem;" />
        </strong>
    </div>
</template>