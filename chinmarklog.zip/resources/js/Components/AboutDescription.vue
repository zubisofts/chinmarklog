<template>
    <div id="servdescr" class=" h-30">
        <div class="">
            <div class="container max-w-6xl py-6 mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
                <!-- Grid Colunm 6 -->
                <div class="py-9 px-3 text-white red_bg">
                    <div class="text-xl italic" style="padding: 0 2px;">
                        <p class="mt-3">
                            At Chinmark Logistics we provide an advantage of swift, effective and seamless delivery, intra state and intra state delivery.
                        </p>
                        <p class="mt-3">
                            Chinmark Logistics is a premium, all inclusive service which collects and delivers shipment and parcels in the shortest possible time while satisfying customer’s needs.
                        </p>
                    </div>
                </div>
                <!-- Grid Colunm 6 -->
                <div class="text-white">
                    <div class="">
                        <img src="/images/img3.jpeg" alt="" class="mx-auto" style="max-height:100%; max-width:100%;">
                    </div>
                </div>
                 <!-- Grid Colunm 6 -->
                <div class="text-white">
                    <div class="">
                        <img src="/images/img4.jpeg" alt="" class="mx-auto" style="max-height:100%; max-width:100%;">
                    </div>
                </div>

                <!-- Grid Colunm 6 -->
                <div class="py-9 px-3 text-white red_bg">
                    <div class="text-xl italic px-6" style="padding: 0 2px;">
                        <p class="mt-3">
                            At Chinmark Group, we are focused on creating ways to serve our clients and customers better, our aim is to ensure trustworthiness, transparency, accountability and speedy delivery. These are part of the key factors this service will offer to the public.
                        </p>
                        <p class="mt-3">
                            Our logistic services will be available online and offline in these cities: Lagos, Onitsha, Port Harcourt and Abuja.
                        </p>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</template>

<style scoped>
    #serv_descr{
        min-height: 200px;
        background-image: url('/images/atlas.png');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
    .red_bg{
        background-color: rgba(255, 0, 0, 0.7);
    }
</style>