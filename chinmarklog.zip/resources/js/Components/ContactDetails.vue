<template>
    <div class="container mx-auto">
                <div class="row grid grid-cols-1 md:grid-cols-2">

                        <div class="px-6 md:px-1">
                            <div class="mt-16 mb-4" data-aos="fade-up">
                                <img src="/images/logo.png" alt="" class="h-16">
                            </div>
                            <div class="my-8 text-lg" data-aos="fade-up">
                                Feel free to contact us at anytime you need help or have any question!
                            </div>
                            <div class="mb-4" data-aos="fade-up">
                                <p class="mb-3">
                                    <strong class="text-red-700"><font-awesome-icon icon="envelope" /> Mail Us :</strong>
                                    <a href="mailto:info@bondlogistics.com">info@bondlogistics.com</a> <br>
                                    We usually reply almost instatly to all your queries! 
                                </p>
                                <p>
                                    <strong class="text-red-700"><font-awesome-icon icon="phone-alt" /> Call Us :</strong>
                                    <a href="tel:478 236 2056">478 236 2056</a> <br>
                                </p>
                            </div>
                            <div class="mb-4" data-aos="fade-up">
                                <h4>
                                    <strong class="text-red-700">
                                        <font-awesome-icon icon="map-marker" /> CONTACT ADDRESS
                                    </strong>
                                </h4>
                                <p>
                                    <strong>Head Office: </strong>
                                    CHINMARK GROUP, <br> Opposite Citipark Hotels, Unity Estate, Enugu.
                                </p>
                            </div>
                            <div class="mb-4" data-aos="fade-up">
                                <strong>GET CONNECTED</strong>
                                <div class="container text-white pt-4">
                                    <a href="" target="blank" class="h-8 w-8 text-center inline-block rounded-full bg-red-600">
                                        <font-awesome-icon :icon="['fab', 'facebook-square']" class="mt-2" />
                                    </a>
                                    <a href="" target="blank" class="h-8 w-8 text-center inline-block rounded-full bg-red-600">
                                        <font-awesome-icon :icon="['fab', 'whatsapp']" class="mt-2" />
                                    </a>
                                    <a href="" target="blank" class="h-8 w-8 text-center inline-block rounded-full bg-red-600">
                                        <font-awesome-icon :icon="['fab', 'instagram']" class="mt-2" />
                                    </a>
                                    <a href="" target="blank" class="h-8 w-8 text-center inline-block rounded-full bg-red-600">
                                        <font-awesome-icon :icon="['fab', 'twitter']" class="mt-2" />
                                    </a>
                                    <a href="" target="blank" class="h-8 w-8 text-center inline-block rounded-full bg-red-600">
                                        <font-awesome-icon :icon="['fab', 'youtube']" class="mt-2" />
                                    </a>
                                </div>
                            </div>

                        </div>

                        <div class="py-8 md:py-16 px-2" data-aos="fade-up-left">
                            <iframe
                                width="600"
                                height="450"
                                style="max-width:100%; border:0"
                                src="https://www.google.com/maps/embed/v1/place?key=AIzaSyC2doiG-W_MC-vbOLzhFO-EF8MCwOAN3bM
                                    &q=CHINMARK+GROUP" allowfullscreen>
                            </iframe>
                        </div>
                </div>
    </div>
</template>

<style scoped>
    #contact-details{
        min-height: 600px;
    }
    h1{
        font-size: 2.5rem;
        color: #cc791a;
        line-height: 2.4rem;
        font-weight: bolder;
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    }
</style>

<script>
export default {

}
</script>
